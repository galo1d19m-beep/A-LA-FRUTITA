# Checklist inicio de vista web

- [x] Pre-requisitos instalados (Node, npm)
- [x] Proyecto creado o descargado
- [x] Dependencias instaladas
- [x] Variable de entorno REACT_APP_API_URL configurada
- [x] API utils creada
- [x] Estructura básica de rutas y componentes lista
- [x] Primeras vistas funcionales conectadas al backend
- [x] App corriendo en localhost:3000
- [x] Pruebas de conexión realizadas