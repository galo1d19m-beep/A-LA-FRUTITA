# Checklist de diseño web A LA FRUTITA

- [x] Paleta de colores definida
- [x] Tipografía y logotipo agregados
- [x] Librería de componentes instalada
- [x] Layout principal creado
- [x] Navegación implementada
- [x] Páginas principales diseñadas
- [x] Estilos globales personalizados
- [x] Pruebas de usabilidad y responsividad realizadas