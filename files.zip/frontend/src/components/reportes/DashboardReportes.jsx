import React, { useEffect, useState } from 'react';
import { get } from '../../utils/api';

const DashboardReportes = () => {
  const [ventas, setVentas] = useState([]);

  useEffect(() => {
    const cargarVentas = async () => {
      setVentas(await get('/api/ventas/'));
    };
    cargarVentas();
  }, []);

  const ventasPorFecha = ventas.reduce((acc, v) => {
    const fecha = new Date(v.fecha).toISOString().slice(0,10);
    acc[fecha] = (acc[fecha] || 0) + v.total;
    return acc;
  }, {});

  const fechas = Object.keys(ventasPorFecha).sort();
  const totales = fechas.map(f => ventasPorFecha[f]);

  return (
    <div style={{ marginTop: 24 }}>
      <h3>Dashboard de Ventas</h3>
      <div style={{ height: 200, background: '#e7f7ea', borderRadius: 8, padding: 16 }}>
        <svg width="100%" height="180">
          {fechas.map((fecha, idx) => (
            <rect
              key={fecha}
              x={idx * 40 + 30}
              y={180 - totales[idx] * 2}
              width={30}
              height={totales[idx] * 2}
              fill="#76BA1B"
            />
          ))}
          {fechas.map((fecha, idx) => (
            <text key={fecha} x={idx * 40 + 35} y={175} fontSize="10">{fecha.slice(5)}</text>
          ))}
        </svg>
        <div style={{ marginTop: 8 }}>
          <span>Ventas totales: <b>${totales.reduce((a,b) => a+b, 0)}</b></span>
        </div>
      </div>
    </div>
  );
};

export default DashboardReportes;