import React, { useEffect, useState } from 'react';
import { get } from '../../utils/api';

const AlertasInventario = () => {
  const [alertas, setAlertas] = useState([]);

  useEffect(() => {
    const cargarAlertas = async () => {
      const data = await get('/api/inventario/alertas');
      setAlertas(data);
    };
    cargarAlertas();
  }, []);

  return (
    <div style={{ marginTop: 24 }}>
      <h3>Alertas de Inventario</h3>
      {alertas.length === 0 ? (
        <div>No hay alertas</div>
      ) : (
        <table style={{ width: '100%', background: '#ffeaea', borderRadius: 8 }}>
          <thead>
            <tr>
              <th>Producto</th>
              <th>Stock</th>
              <th>Alerta</th>
            </tr>
          </thead>
          <tbody>
            {alertas.map((p, idx) => (
              <tr key={p._id || idx} style={{ color: 'red' }}>
                <td>{p.nombre}</td>
                <td>{p.stock}</td>
                <td>{p.alertaStock}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default AlertasInventario;