import React, { useState } from 'react';
import { post } from '../../utils/api';

const FeedbackForm = () => {
  const [mensaje, setMensaje] = useState('');
  const [enviado, setEnviado] = useState(false);

  const enviarFeedback = async () => {
    await post('/api/feedback', { mensaje });
    setEnviado(true);
  };

  return (
    <div>
      <h4>¿Encontraste un problema? ¿Tienes sugerencias?</h4>
      {enviado ? (
        <div>¡Gracias por tu feedback!</div>
      ) : (
        <form onSubmit={e => { e.preventDefault(); enviarFeedback(); }}>
          <textarea value={mensaje} onChange={e => setMensaje(e.target.value)} />
          <button type="submit">Enviar</button>
        </form>
      )}
    </div>
  );
};

export default FeedbackForm;