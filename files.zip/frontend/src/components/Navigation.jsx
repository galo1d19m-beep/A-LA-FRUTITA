import { Drawer, List, ListItem, ListItemText } from '@mui/material';
import { Link } from 'react-router-dom';

export default function Navigation() {
  return (
    <Drawer variant="permanent">
      <List>
        <ListItem button component={Link} to="/ventas">
          <ListItemText primary="Ventas" />
        </ListItem>
        <ListItem button component={Link} to="/inventario">
          <ListItemText primary="Inventario" />
        </ListItem>
        <ListItem button component={Link} to="/reportes">
          <ListItemText primary="Reportes" />
        </ListItem>
        <ListItem button component={Link} to="/usuarios">
          <ListItemText primary="Usuarios" />
        </ListItem>
      </List>
    </Drawer>
  );
}