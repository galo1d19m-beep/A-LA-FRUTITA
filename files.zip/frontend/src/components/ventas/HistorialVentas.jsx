import React, { useEffect, useState } from 'react';
import { get } from '../../utils/api';

const HistorialVentas = () => {
  const [ventas, setVentas] = useState([]);
  const [filtroUsuario, setFiltroUsuario] = useState('');
  const [filtroFecha, setFiltroFecha] = useState('');
  const [usuarios, setUsuarios] = useState([]);

  useEffect(() => {
    const cargarDatos = async () => {
      setVentas(await get('/api/ventas/'));
      setUsuarios(await get('/api/usuarios/'));
    };
    cargarDatos();
  }, []);

  const ventasFiltradas = ventas.filter(v => {
    const porUsuario = filtroUsuario ? v.usuarioId?._id === filtroUsuario : true;
    const porFecha = filtroFecha ? new Date(v.fecha).toISOString().slice(0,10) === filtroFecha : true;
    return porUsuario && porFecha;
  });

  return (
    <div style={{ marginTop: 24 }}>
      <h3>Historial de Ventas</h3>
      <div style={{ display: 'flex', gap: 16, marginBottom: 16 }}>
        <select value={filtroUsuario} onChange={e => setFiltroUsuario(e.target.value)}>
          <option value="">Todos los cajeros</option>
          {usuarios.map(u => <option key={u._id} value={u._id}>{u.nombre}</option>)}
        </select>
        <input
          type="date"
          value={filtroFecha}
          onChange={e => setFiltroFecha(e.target.value)}
        />
      </div>
      <table style={{ width: '100%', background: '#f7f7f7', borderRadius: 8 }}>
        <thead>
          <tr>
            <th>Fecha</th>
            <th>Cajero</th>
            <th>Método Pago</th>
            <th>Total</th>
            <th>Productos</th>
          </tr>
        </thead>
        <tbody>
          {ventasFiltradas.map((venta, idx) => (
            <tr key={venta._id || idx}>
              <td>{new Date(venta.fecha).toLocaleString()}</td>
              <td>{venta.usuarioId?.nombre || '---'}</td>
              <td>{venta.metodoPago}</td>
              <td>${venta.total}</td>
              <td>
                <ul style={{ margin: 0 }}>
                  {venta.productos.map((p, i) => (
                    <li key={i}>
                      {p.cantidad} x {p.productoId?.nombre || '-'}
                    </li>
                  ))}
                </ul>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div style={{ marginTop: 16 }}>
        <a href="/api/reportes/ventas/pdf" target="_blank" rel="noopener noreferrer">
          <button>Exportar a PDF</button>
        </a>
        <a href="/api/reportes/ventas/excel" target="_blank" rel="noopener noreferrer">
          <button>Exportar a Excel</button>
        </a>
      </div>
    </div>
  );
};

export default HistorialVentas;