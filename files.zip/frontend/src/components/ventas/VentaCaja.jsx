import React, { useState, useEffect } from 'react';
import { post, get } from '../../utils/api';

const VentaCaja = () => {
  // Estado de productos y usuarios reales
  const [productos, setProductos] = useState([]);
  const [usuarios, setUsuarios] = useState([]);
  const [turno, setTurno] = useState(null);

  // Estado de la venta
  const [productosVenta, setProductosVenta] = useState([]);
  const [busqueda, setBusqueda] = useState('');
  const [total, setTotal] = useState(0);
  const [metodoPago, setMetodoPago] = useState('efectivo');
  const [ticket, setTicket] = useState(null);
  const [usuarioActivo, setUsuarioActivo] = useState('');

  // Cargar productos y usuarios al montar
  useEffect(() => {
    const cargarDatos = async () => {
      setProductos(await get('/api/inventario/'));
      setUsuarios(await get('/api/usuarios/'));
    };
    cargarDatos();
  }, []);

  // Buscar y agregar producto al carrito
  const buscarProducto = () => {
    const prod = productos.find(p => p.nombre.toLowerCase().includes(busqueda.toLowerCase()));
    if (prod) {
      setProductosVenta([...productosVenta, { ...prod, cantidad: 1, subtotal: prod.precio }]);
      setTotal(total + prod.precio);
      setBusqueda('');
    }
  };

  // Abrir turno
  const abrirTurno = async () => {
    if (!usuarioActivo) return alert('Selecciona un usuario');
    const resp = await post('/api/turnos/abrir', { usuarioId: usuarioActivo });
    setTurno(resp);
  };

  // Confirmar venta
  const confirmarVenta = async () => {
    if (!turno) return alert('Abre turno primero');
    const ventaPayload = {
      productos: productosVenta.map(p => ({
        productoId: p._id,
        cantidad: p.cantidad,
        precioUnitario: p.precio,
        descuento: 0
      })),
      total,
      metodoPago,
      usuarioId: usuarioActivo,
      fecha: new Date().toISOString(),
      promociones: [],
      turnoId: turno._id
    };
    const resp = await post('/api/ventas/nueva', ventaPayload);
    setTicket({
      productos: productosVenta,
      total,
      metodoPago,
      fecha: new Date().toLocaleString(),
      ventaId: resp._id
    });
    setProductosVenta([]);
    setTotal(0);
  };

  return (
    <div style={{ maxWidth: 600, margin: 'auto', padding: 24, background: '#fffbe6', borderRadius: 12 }}>
      <h2 style={{ color: '#76BA1B' }}>A LA FRUTITA - Punto de Venta</h2>
      <div>
        <select value={usuarioActivo} onChange={e => setUsuarioActivo(e.target.value)}>
          <option value="">-- Selecciona cajero --</option>
          {usuarios.map(u => <option key={u._id} value={u._id}>{u.nombre}</option>)}
        </select>
        <button onClick={abrirTurno}>Abrir Turno</button>
      </div>
      <div style={{ marginTop: 16 }}>
        <input
          type="text"
          value={busqueda}
          placeholder="Buscar producto..."
          onChange={e => setBusqueda(e.target.value)}
        />
        <button onClick={buscarProducto}>Agregar</button>
      </div>
      <table style={{ width: '100%', marginTop: 20 }}>
        <thead>
          <tr>
            <th>Producto</th>
            <th>Cant</th>
            <th>Precio</th>
            <th>Subtotal</th>
          </tr>
        </thead>
        <tbody>
          {productosVenta.map((prod, idx) => (
            <tr key={idx}>
              <td>{prod.nombre}</td>
              <td>{prod.cantidad}</td>
              <td>${prod.precio}</td>
              <td>${prod.subtotal}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div style={{ marginTop: 16, fontWeight: 'bold' }}>Total: ${total}</div>
      <div style={{ marginTop: 16 }}>
        <button onClick={() => setMetodoPago('efectivo')}>Efectivo</button>
        <button onClick={() => setMetodoPago('tarjeta')}>Tarjeta</button>
        <button onClick={() => setMetodoPago('puntos')}>Puntos</button>
        <button onClick={() => setMetodoPago('vales')}>Vales</button>
      </div>
      <button style={{ marginTop: 16, background: '#FFB347', padding: '8px 16px', border: 'none', borderRadius: 6 }}
        onClick={confirmarVenta}>Confirmar Venta</button>
      {ticket && (
        <div style={{ marginTop: 32, padding: 16, background: '#eaf9ea', borderRadius: 8 }}>
          <h3>Ticket</h3>
          <div>Fecha: {ticket.fecha}</div>
          <div>Método de pago: {ticket.metodoPago}</div>
          <div>Total: ${ticket.total}</div>
          <ul>
            {ticket.productos.map((prod, idx) => (
              <li key={idx}>{prod.cantidad} x {prod.nombre} = ${prod.subtotal}</li>
            ))}
          </ul>
          <div>ID Venta: {ticket.ventaId}</div>
        </div>
      )}
    </div>
  );
};

export default VentaCaja;