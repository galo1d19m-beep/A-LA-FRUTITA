import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Inventario from './pages/Inventario';
import Ventas from './pages/Ventas';
import Reportes from './pages/Reportes';
import Usuarios from './pages/Usuarios';
import Servicios from './pages/Servicios';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/inventario" element={<Inventario />} />
        <Route path="/ventas" element={<Ventas />} />
        <Route path="/reportes" element={<Reportes />} />
        <Route path="/usuarios" element={<Usuarios />} />
        <Route path="/servicios" element={<Servicios />} />
        <Route path="/" element={<Ventas />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;