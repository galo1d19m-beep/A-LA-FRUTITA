import React, { useEffect, useState } from 'react';
import { get } from '../utils/api';

const Inventario = () => {
  const [productos, setProductos] = useState([]);

  useEffect(() => {
    get('/api/inventario').then(setProductos);
  }, []);

  return (
    <div>
      <h2>Inventario</h2>
      <table>
        <thead>
          <tr>
            <th>Producto</th>
            <th>Stock</th>
            <th>Precio</th>
          </tr>
        </thead>
        <tbody>
          {productos.map(p => (
            <tr key={p._id}>
              <td>{p.nombre}</td>
              <td>{p.stock}</td>
              <td>${p.precio}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Inventario;