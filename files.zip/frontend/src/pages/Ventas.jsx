import { Button, TextField, Table, TableHead, TableRow, TableCell, TableBody, Paper } from '@mui/material';

export default function Ventas() {
  // Estado y lógica omitidos por brevedad
  return (
    <Paper sx={{ p: 2 }}>
      <h2>Venta rápida</h2>
      <TextField label="Buscar producto" variant="outlined" fullWidth sx={{ mb: 2 }} />
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Producto</TableCell>
            <TableCell>Cantidad</TableCell>
            <TableCell>Subtotal</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {/* Mapea productos seleccionados */}
        </TableBody>
      </Table>
      <Button variant="contained" color="primary" sx={{ mt: 2 }}>Confirmar venta</Button>
    </Paper>
  );
}