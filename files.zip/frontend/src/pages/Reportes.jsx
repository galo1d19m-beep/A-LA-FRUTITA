import React from 'react';
import DashboardReportes from '../components/reportes/DashboardReportes';
import HistorialVentas from '../components/ventas/HistorialVentas';
import AlertasInventario from '../components/inventario/AlertasInventario';

const Reportes = () => (
  <div>
    <DashboardReportes />
    <HistorialVentas />
    <AlertasInventario />
  </div>
);

export default Reportes;