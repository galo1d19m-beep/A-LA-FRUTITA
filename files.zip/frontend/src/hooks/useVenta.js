import { post } from '../utils/api';

export const useVenta = () => {
  const crearVenta = async (data) => await post('/api/ventas/nueva', data);
  return { crearVenta };
};