import axios from 'axios';

const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL,
});

export const get = (url) => api.get(url).then(res => res.data);
export const post = (url, data) => api.post(url, data).then(res => res.data);
export const put = (url, data) => api.put(url, data).then(res => res.data);
export default api;