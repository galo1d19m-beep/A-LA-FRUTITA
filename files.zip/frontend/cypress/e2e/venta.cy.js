describe('Venta completa', () => {
  it('Realiza una venta y muestra el ticket', () => {
    cy.visit('http://localhost:3000');
    cy.get('select').select('Carlos');
    cy.contains('Abrir Turno').click();
    cy.get('input[placeholder="Buscar producto..."]').type('Manzana');
    cy.contains('Agregar').click();
    cy.contains('Confirmar Venta').click();
    cy.contains('Ticket').should('exist');
    cy.contains('Total: $').should('exist');
  });
});