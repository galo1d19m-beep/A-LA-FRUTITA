#!/bin/bash
FECHA=$(date +"%Y-%m-%d_%H-%M-%S")
mongodump --db alafrutita --out /backups/alafrutita_$FECHA