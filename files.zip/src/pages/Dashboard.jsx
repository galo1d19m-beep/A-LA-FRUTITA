import { Box, Typography, Paper, Grid, Button } from '@mui/material';

export default function Dashboard() {
  return (
    <Box>
      <Typography variant="h2" color="primary" mb={3}>
        Bienvenido a A LA FRUTITA
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Paper elevation={3} sx={{ p: 3, borderRadius: 4, bgcolor: 'secondary.main', color: 'secondary.contrastText' }}>
            <Typography variant="h5">Ventas del día</Typography>
            <Typography variant="h3" mt={2}>$1,250.00</Typography>
            <Button variant="contained" color="primary" sx={{ mt: 2 }}>
              Ver detalle
            </Button>
          </Paper>
        </Grid>
        <Grid item xs={12} md={4}>
          <Paper elevation={3} sx={{ p: 3, borderRadius: 4 }}>
            <Typography variant="h5" color="primary">Productos bajos en inventario</Typography>
            <Typography variant="body1" mt={2}>3 productos con alerta</Typography>
            <Button variant="outlined" color="primary" sx={{ mt: 2 }}>
              Revisar inventario
            </Button>
          </Paper>
        </Grid>
        <Grid item xs={12} md={4}>
          <Paper elevation={3} sx={{ p: 3, borderRadius: 4 }}>
            <Typography variant="h5" color="primary">Corte de caja</Typography>
            <Typography variant="body2" mt={2}>Último corte: 18:30</Typography>
            <Button variant="contained" color="secondary" sx={{ mt: 2 }}>
              Realizar corte
            </Button>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}