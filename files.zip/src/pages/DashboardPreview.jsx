import { Box, Typography, Grid, Paper, Button } from '@mui/material';

export default function DashboardPreview() {
  return (
    <Box sx={{ p: 4, bgcolor: 'background.default', minHeight: '100vh' }}>
      <Typography variant="h2" color="primary" mb={4}>
        Bienvenido a A LA FRUTITA 🍏
      </Typography>
      <Grid container spacing={4}>
        {/* Ventas del día */}
        <Grid item xs={12} md={4}>
          <Paper elevation={3} sx={{ p: 3, borderRadius: 3, bgcolor: 'secondary.main', color: 'secondary.contrastText' }}>
            <Typography variant="h5">Ventas del día</Typography>
            <Typography variant="h3" mt={2}>$1,250.00</Typography>
            <Button variant="contained" color="primary" sx={{ mt: 2 }}>
              Ver detalle
            </Button>
          </Paper>
        </Grid>
        {/* Alertas de inventario */}
        <Grid item xs={12} md={4}>
          <Paper elevation={3} sx={{ p: 3, borderRadius: 3 }}>
            <Typography variant="h5" color="primary">Inventario bajo</Typography>
            <Typography variant="body1" mt={2}>3 productos con alerta</Typography>
            <Button variant="outlined" color="primary" sx={{ mt: 2 }}>
              Revisar inventario
            </Button>
          </Paper>
        </Grid>
        {/* Corte de caja */}
        <Grid item xs={12} md={4}>
          <Paper elevation={3} sx={{ p: 3, borderRadius: 3 }}>
            <Typography variant="h5" color="primary">Corte de caja</Typography>
            <Typography variant="body2" mt={2}>Último corte: 18:30</Typography>
            <Button variant="contained" color="secondary" sx={{ mt: 2 }}>
              Realizar corte
            </Button>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}