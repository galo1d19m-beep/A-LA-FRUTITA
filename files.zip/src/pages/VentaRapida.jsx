import { Box, TextField, Button, Typography, Paper } from '@mui/material';
import { useState } from 'react';

export default function VentaRapida() {
  const [codigo, setCodigo] = useState('');
  const [cantidad, setCantidad] = useState(1);

  return (
    <Paper sx={{ p: 4, maxWidth: 400, mx: 'auto', mt: 4 }}>
      <Typography variant="h4" color="primary" mb={2}>Venta rápida</Typography>
      <TextField 
        label="Código de barras" 
        variant="outlined" 
        fullWidth 
        value={codigo} 
        onChange={e => setCodigo(e.target.value)} 
        sx={{ mb: 2 }} 
      />
      <TextField 
        label="Cantidad" 
        variant="outlined" 
        type="number" 
        fullWidth 
        value={cantidad} 
        onChange={e => setCantidad(Number(e.target.value))} 
        sx={{ mb: 2 }} 
      />
      <Button variant="contained" color="primary" fullWidth>
        Registrar venta
      </Button>
    </Paper>
  );
}