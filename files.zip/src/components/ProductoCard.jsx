import { Card, CardContent, CardActions, Typography, Button } from '@mui/material';

export default function ProductoCard({ producto, onAgregar }) {
  return (
    <Card sx={{ minWidth: 220, borderRadius: 3, bgcolor: producto.stock <= producto.alertaStock ? 'warning.light' : 'background.paper' }}>
      <CardContent>
        <Typography variant="h6" color="primary">{producto.nombre}</Typography>
        <Typography variant="body2">Stock: {producto.stock}</Typography>
        <Typography variant="body2">Precio: ${producto.precio}</Typography>
      </CardContent>
      <CardActions>
        <Button 
          variant="contained" 
          color="primary" 
          size="small" 
          onClick={() => onAgregar(producto)}
        >
          Agregar
        </Button>
      </CardActions>
    </Card>
  );
}