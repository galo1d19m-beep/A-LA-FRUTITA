import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    primary: {
      main: '#7CC142', // Verde frutal
      contrastText: '#fff'
    },
    secondary: {
      main: '#FFD600', // Amarillo frutal
      contrastText: '#333'
    },
    error: {
      main: '#D32F2F',
    },
    background: {
      default: '#F9F9F9',
      paper: '#fff',
    },
    info: {
      main: '#3FB4F6'
    },
    success: {
      main: '#4CAF50'
    },
    warning: {
      main: '#FFA726'
    }
  },
  typography: {
    fontFamily: '"Montserrat", "Roboto", "Arial", sans-serif',
    h1: { fontWeight: 700 },
    h2: { fontWeight: 600 },
    h3: { fontWeight: 500 },
    button: { textTransform: 'none', fontWeight: 600 }
  },
  shape: {
    borderRadius: 12
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'linear-gradient(90deg, #7CC142 0%, #FFD600 100%)',
        }
      }
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 24,
        }
      }
    }
  }
});

export default theme;