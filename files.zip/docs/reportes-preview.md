```plaintext
+-------------------------------+
|   Dashboard de Ventas         |
|   [Gráfica barras por día]    |
|   Ventas totales: $XXX        |
+-------------------------------+
|   Historial de Ventas         |
|   [Filtros cajero y fecha]    |
|   [Tabla]                     |
|   [Exportar PDF/Excel]        |
+-------------------------------+
|   Alertas de Inventario       |
|   [Tabla de productos con poca|
|    existencia]                |
+-------------------------------+
```