```plaintext
+-----------------------------------------------+
|      A LA FRUTITA - Punto de Venta            |
+-----------------------------------------------+
|  [Buscar producto] [Agregar]                  |
|                                               |
|  Productos en venta:                          |
|  -------------------------------------------  |
|  | Producto     | Cant | Precio | Subtotal |  |
|  -------------------------------------------  |
|  | Manzana      |  1   | $10    | $10      |  |
|  | Plátano      |  1   | $8     | $8       |  |
|  -------------------------------------------  |
|                                               |
|  Total: $18                                  |
|                                               |
|  [Efectivo] [Tarjeta] [Puntos] [Vales]        |
|                                               |
|  [Confirmar Venta]                            |
|                                               |
|  [Ticket generado]                            |
|  Fecha: 2025-08-28 19:07                      |
|  Método de pago: efectivo                     |
|  Total: $18                                   |
|  Manzana x1 = $10                             |
|  Plátano x1 = $8                              |
|  ID Venta: 64ed1b...                          |
+-----------------------------------------------+
```