# QA Manual - A LA FRUTITA

## Pruebas funcionales

- [ ] Registrar producto
- [ ] Registrar usuario/cajero
- [ ] Abrir turno
- [ ] Realizar venta
- [ ] Visualizar historial y dashboard
- [ ] Exportar PDF/Excel
- [ ] Ver alertas de inventario
- [ ] Cerrar turno / corte de caja
- [ ] Validación de errores (stock insuficiente, datos faltantes)
- [ ] Pruebas multiusuario

## Pruebas de integración

- [ ] Prueba de flujo completo (registro -> venta -> corte de caja -> reporte)
- [ ] Prueba de servicios externos (si se usan)

## Pruebas de despliegue

- [ ] Backend responde en el puerto correcto
- [ ] Base de datos conecta y guarda info
- [ ] Frontend consume correctamente el backend