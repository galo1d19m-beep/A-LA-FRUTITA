# Reporte de Bug / QA - A LA FRUTITA

**Fecha:** YYYY-MM-DD  
**Reportado por:** Nombre / Usuario

## Descripción

(Describe el error/problema encontrado)

## Pasos para reproducir

1. Paso uno...
2. Paso dos...
3. ...

## Resultado esperado

(Describe qué debería ocurrir)

## Resultado actual

(Describe lo que ocurre realmente)

## Evidencia

- Capturas de pantalla
- Logs del navegador
- Logs del servidor

## Prioridad

- Alta / Media / Baja

## Notas adicionales

(Comentarios, sugerencias, posibles soluciones)