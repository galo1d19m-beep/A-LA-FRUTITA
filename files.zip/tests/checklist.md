# Pruebas funcionales A LA FRUTITA

- [x] Registro de productos
- [x] Registro de usuarios/cajeros
- [x] Apertura de turno
- [x] Realizar venta (flujo completo)
- [x] Visualización de historial y dashboard
- [x] Exportación a PDF y Excel
- [x] Alertas de inventario
- [x] Cierre de turno y corte de caja
- [x] Validación de errores y seguridad