# Checklist Tema Visual A LA FRUTITA

- [x] Paleta de colores personalizada
- [x] Tipografía definida
- [x] Bordes y estilos personalizados
- [x] AppBar y botones con estilo propio
- [x] Fuente Montserrat agregada
- [x] Tema aplicado globalmente