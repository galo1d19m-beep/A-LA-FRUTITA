const mongoose = require('mongoose');
const VentaSchema = new mongoose.Schema({
  productos: [
    {
      productoId: { type: mongoose.Schema.Types.ObjectId, ref: 'Producto' },
      cantidad: Number,
      precioUnitario: Number,
      descuento: Number
    }
  ],
  total: Number,
  metodoPago: String,
  usuarioId: { type: mongoose.Schema.Types.ObjectId, ref: 'Usuario' },
  fecha: Date,
  promociones: [String],
  turnoId: { type: mongoose.Schema.Types.ObjectId, ref: 'Turno' }
});
module.exports = mongoose.model('Venta', VentaSchema);