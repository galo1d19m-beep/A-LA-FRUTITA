const mongoose = require('mongoose');
const TurnoSchema = new mongoose.Schema({
  usuarioId: { type: mongoose.Schema.Types.ObjectId, ref: 'Usuario' },
  fechaApertura: Date,
  fechaCierre: Date,
  ventas: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Venta' }],
  total: Number
});
module.exports = mongoose.model('Turno', TurnoSchema);