const mongoose = require('mongoose');
const Producto = require('../Producto');

describe('Producto Model', () => {
  beforeAll(async () => {
    await mongoose.connect(process.env.MONGODB_URI);
  });

  afterAll(async () => {
    await mongoose.connection.close();
  });

  it('Crea un producto correctamente', async () => {
    const prod = new Producto({
      nombre: 'Test',
      categoria: 'Fruta',
      proveedor: 'Proveedor',
      stock: 10,
      precio: 15,
      codigoBarras: '9876543210987',
      alertaStock: 5,
      etiquetas: ['prueba']
    });
    const saved = await prod.save();
    expect(saved.nombre).toBe('Test');
    await Producto.deleteOne({ _id: saved._id });
  });
});