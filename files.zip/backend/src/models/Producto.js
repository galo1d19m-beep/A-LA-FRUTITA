const mongoose = require('mongoose');
const ProductoSchema = new mongoose.Schema({
  nombre: String,
  categoria: String,
  proveedor: String,
  stock: Number,
  precio: Number,
  fechaCaducidad: Date,
  codigoBarras: String,
  alertaStock: Number,
  etiquetas: [String]
});
module.exports = mongoose.model('Producto', ProductoSchema);