const nodemailer = require('nodemailer');
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

function sendAlert(subject, message) {
  transporter.sendMail({
    from: process.env.SMTP_USER,
    to: 'admin@tudominio.com',
    subject,
    text: message,
  }, (err, info) => {
    if (err) console.error('Error enviando alerta:', err);
  });
}

module.exports = sendAlert;