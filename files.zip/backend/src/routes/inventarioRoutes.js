const express = require('express');
const router = express.Router();
const inventarioController = require('../controllers/inventarioController');

router.post('/crear', inventarioController.crearProducto);
router.get('/', inventarioController.listarProductos);
router.get('/alertas', inventarioController.alertasInventario);

module.exports = router;