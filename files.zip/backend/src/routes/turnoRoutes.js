const express = require('express');
const router = express.Router();
const turnoController = require('../controllers/turnoController');

router.post('/abrir', turnoController.abrirTurno);
router.post('/cerrar', turnoController.cerrarTurno);
router.get('/:id', turnoController.obtenerTurno);

module.exports = router;