const express = require('express');
const router = express.Router();
const reporteController = require('../controllers/reporteController');

router.get('/ventas/pdf', reporteController.exportarVentasPDF);
router.get('/ventas/excel', reporteController.exportarVentasExcel);

module.exports = router;