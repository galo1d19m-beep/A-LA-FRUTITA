const express = require('express');
const router = express.Router();
const ventaController = require('../controllers/ventaController');

router.post('/nueva', ventaController.nuevaVenta);
router.get('/', ventaController.listarVentas);

module.exports = router;