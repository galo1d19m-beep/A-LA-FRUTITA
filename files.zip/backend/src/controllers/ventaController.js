const Venta = require('../models/Venta');
const Turno = require('../models/Turno');
const Producto = require('../models/Producto');

exports.nuevaVenta = async (req, res) => {
  try {
    const venta = new Venta(req.body);
    await venta.save();
    for (const item of req.body.productos) {
      await Producto.findByIdAndUpdate(item.productoId, { $inc: { stock: -item.cantidad } });
    }
    await Turno.findByIdAndUpdate(req.body.turnoId, {
      $push: { ventas: venta._id },
      $inc: { total: venta.total }
    });
    res.status(201).json(venta);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.listarVentas = async (req, res) => {
  try {
    const ventas = await Venta.find().populate('productos.productoId usuarioId turnoId');
    res.json(ventas);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};