const Turno = require('../models/Turno');

exports.abrirTurno = async (req, res) => {
  try {
    const turno = new Turno({
      usuarioId: req.body.usuarioId,
      fechaApertura: new Date(),
      ventas: [],
      total: 0
    });
    await turno.save();
    res.status(201).json(turno);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.cerrarTurno = async (req, res) => {
  try {
    const turno = await Turno.findByIdAndUpdate(
      req.body.turnoId,
      { fechaCierre: new Date() },
      { new: true }
    );
    res.json({ corte: turno.total, ventas: turno.ventas, turno });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.obtenerTurno = async (req, res) => {
  try {
    const turno = await Turno.findById(req.params.id);
    res.json(turno);
  } catch (err) {
    res.status(404).json({ error: 'Turno no encontrado' });
  }
};