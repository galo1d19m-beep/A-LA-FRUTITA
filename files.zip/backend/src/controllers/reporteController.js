const Venta = require('../models/Venta');
const { generarPDF } = require('../utils/pdf');
const { generarExcel } = require('../utils/excel');

exports.exportarVentasPDF = async (req, res) => {
  try {
    const ventas = await Venta.find();
    const pdfBuffer = generarPDF(ventas);
    res.set('Content-Type', 'application/pdf');
    res.send(pdfBuffer);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.exportarVentasExcel = async (req, res) => {
  try {
    const ventas = await Venta.find();
    const excelBuffer = generarExcel(ventas);
    res.set('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.send(excelBuffer);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};