const Producto = require('../models/Producto');

exports.crearProducto = async (req, res) => {
  try {
    const producto = new Producto(req.body);
    await producto.save();
    res.status(201).json(producto);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.listarProductos = async (req, res) => {
  try {
    const productos = await Producto.find();
    res.json(productos);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.alertasInventario = async (req, res) => {
  try {
    const productos = await Producto.find({ $expr: { $lte: ["$stock", "$alertaStock"] } });
    res.json(productos);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};