# A LA FRUTITA - Backend

## Requisitos

- Node.js >= 16
- MongoDB local o Atlas

## Instalación

```bash
npm install
```

## Configuración

1. Crea el archivo `.env` en la raíz:
    ```
    MONGODB_URI=mongodb://localhost:27017/alafrutita
    PORT=4000
    NODE_ENV=development
    ```
2. (Opcional) Agrega tus claves de servicios externos si los usas.

## Ejecución

```bash
npm run dev
```

## Rutas principales

- `/api/inventario` (productos)
- `/api/usuarios` (usuarios/cajeros)
- `/api/turnos` (apertura/cierre turnos)
- `/api/ventas` (ventas)
- `/api/reportes` (exportar PDF/Excel)

## Pruebas

- Usa Postman/Insomnia para probar los endpoints.
- Usa el frontend para pruebas de usuario.

## Docker

### Construcción

```bash
docker build -t alafrutita-backend .
```
### Ejecución

```bash
docker run -p 4000:4000 --env-file .env alafrutita-backend
```