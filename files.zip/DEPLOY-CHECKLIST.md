# Checklist Producción A LA FRUTITA

- [x] Variables de entorno configuradas
- [x] MongoDB Atlas/local conectado y respaldado
- [x] Backend dockerizado y corriendo
- [x] Frontend apuntando a backend correcto
- [x] Pruebas automáticas (Jest y Cypress) pasan
- [x] Exportaciones PDF/Excel funcionan
- [x] Alertas de inventario funcionan
- [x] Corte de caja y cierre de turno OK
- [x] Seguridad básica y backups activos
- [x] Documentación actualizada